const btn = document.querySelector('.order-button');
btn.addEventListener('click', function() {
  btn.innerHTML = ('Взято!')
  btn.style.backgroundColor = 'lightpink'
})